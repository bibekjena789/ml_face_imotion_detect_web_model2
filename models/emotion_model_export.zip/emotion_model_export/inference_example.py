import torch
import torch.nn as nn
from PIL import Image
from torchvision import models, transforms

MODEL_PATH = "emotion_efficientnet_b0.pth"
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
ckpt = torch.load(MODEL_PATH, map_location=DEVICE, weights_only=False)
model = models.efficientnet_b0(weights=None)
model.classifier[1] = nn.Linear(model.classifier[1].in_features, len(ckpt["class_names"]))
model.load_state_dict(ckpt["model_state_dict"])
model.to(DEVICE).eval()
preprocess = transforms.Compose([
    transforms.Resize((ckpt["image_size"], ckpt["image_size"])),
    transforms.ToTensor(),
    transforms.Normalize(ckpt["imagenet_mean"], ckpt["imagenet_std"])
])
def predict_emotion(image_path):
    image = Image.open(image_path).convert("RGB")
    x = preprocess(image).unsqueeze(0).to(DEVICE)
    with torch.no_grad():
        probs = torch.softmax(model(x), dim=1)[0]
    i = int(probs.argmax())
    return {"emotion": ckpt["class_names"][i], "confidence": float(probs[i]),
            "probabilities": {name: float(probs[j]) for j,name in enumerate(ckpt["class_names"])}}
if __name__ == "__main__":
    import sys
    print(predict_emotion(sys.argv[1]))
